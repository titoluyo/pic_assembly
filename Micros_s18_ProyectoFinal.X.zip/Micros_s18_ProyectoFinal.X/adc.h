#ifndef ADC_H
#define	ADC_H

void ADC_Init(void);                  // Iniciaiizacion del ADC
uint16_t ADC_Read(unsigned char ch);  // Lectura del ADC

#endif	/* ADC_H */

